<section>
    <auction-slots></auction-slots>

</section>