<section>
    <div class="container scroller-area" id="auctionProductRibon">
        <div class="row pl-5 pr-5">
            <div class="offers">
                <img class="left-img" src="/images/home/title-arrow.png" alt="">
                Scroll down and click "Bid" to participate in our auctions
                <img class="right-img" src="/images/home/title-arrow-right.png" alt="">
            </div>
        </div>
    </div>
</section>