<section>
    <div class="container winners-area" id="closedAuctionsRibon">
        <div class="row p-1">
            <div class="offers">
                CLOSED PRODUCTS
            </div>
        </div>
    </div>
</section>