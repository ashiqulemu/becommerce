<section>
    <div class="container winners-area" id="live-auctionsRibon">
        <div class="row pl-5 pr-5">
            <div class="offers">
                UPCOMING AUCTIONS
            </div>
        </div>
    </div>
</section>