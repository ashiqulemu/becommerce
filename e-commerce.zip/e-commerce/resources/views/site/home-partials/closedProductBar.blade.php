<section>
    <div class="container winners-area" id="closedAuctionsRibon">
        <div class="row pl-5 pr-5">
            <div class="offers">
                CLOSED PRODUCTS
            </div>
        </div>
    </div>
</section>