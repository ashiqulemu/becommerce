
<section class="mid">
    <div class="container">
        <div class="row">
            <ul class="midNav">
                <li><a href="/user-home#auctionProductRibon">Live Auctions</a></li>
                <li><a href="/user-home#live-auctionsRibon">Upcoming Auctions</a></li>
                <li><a href="/user-home#closedAuctionsRibon">Closed Auctions</a></li>
                <li><a href="/user-home#regularProduct">Regular Product</a></li>
                <li><a href="{{url('/all-products')}}">All Products</a></li>
                <li><a href="{{url('/user-details/all-order')}}">My Orders</a></li>

            </ul>
        </div>
    </div>
</section>