<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StoreIntial extends Model
{
    protected $guarded=['id'];
}
