<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AuctionMedias extends Model
{
    protected $guarded=['id'];
}
