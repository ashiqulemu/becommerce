
<?php $__env->startSection('title-meta'); ?>
    <title>Invoice</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="container bg-white mt-5">

        <i class="fa fa-print printInvoiceBtn" onclick="printMe()"></i>


        <div id="orderInvoice" class="invoiceArea">
            <div class="rows">
                <div class="column">
                    <img width='190px' src="/images/logo.png" alt="">

                </div>
                <div class="column">
                    <strong>
                        Order Number  #<?php echo e($paymentInfo->order_no); ?> <br>
                        Order Date & Time <br>
                        <?php echo e($paymentInfo->created_at); ?>

                    </strong>
                </div>
            </div>
            <hr>
            <div class="rows">
                <div class="column">
                    <strong>
                        Invoice to<br>
                        <?php echo e($paymentInfo->user->name); ?><br>
                        <?php if($paymentInfo->user->mobile): ?>
                        Phone: <?php echo e($paymentInfo->user->mobile); ?><br>
                        <?php endif; ?>
                    </strong>
                </div>







            </div>


            <table class="table invoiceTable">
                <thead>
                <tr>
                    <th scope="col">Sl</th>
                    <th scope="col">Product</th>
                    <th scope="col">Qty</th>
                    <th scope="col">Price</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td scope="row">1</td>
                    <td><?php echo e($paymentInfo->paymentable->name); ?></td>
                    <td>1</td>
                    <td>
                        <?php
                            $subTotal=$paymentInfo->amount;
                            $discount=$paymentInfo->discount_amount;

                        ?>

                        <?php echo e($setting->amount_sign); ?><?php echo e(number_format((float)($subTotal+$discount), 2, '.', '')); ?>



                    </td>
                </tr>

                </tbody>
            </table>
            <div class="rows-invoice">
                <div class="items">&nbsp; </div>
                <div class="items">
                    <div class="item-row">
                        <span>Sub total :</span>
                        <span><?php echo e($setting->amount_sign); ?><?php echo e(number_format((float)($subTotal+$discount), 2, '.', '')); ?></span>
                    </div>
                    <div class="item-row">
                        <span>(-) Discount :</span>
                        <span><?php echo e($setting->amount_sign); ?><?php echo e(number_format((float)($discount), 2, '.', '')); ?></span>
                    </div>
                    <div class="item-row">
                        <span> Grand total :</span>
                        <span> <?php echo e($setting->amount_sign); ?><?php echo e(number_format((float)($subTotal), 2, '.', '')); ?></span>
                    </div>
                </div>
            </div>


            <strong>
                <h6 align='center'> www.billboardbd.com Dhaka Bangladesh Phone: 77665544222, Email:
                    order@billboardbd.com
                </h6>
            </strong>

        </div>

        <br>
        <br>
    </div>




<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>

        function printMe() {
            window.print();
        }

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/pages/payment/invoice.blade.php ENDPATH**/ ?>