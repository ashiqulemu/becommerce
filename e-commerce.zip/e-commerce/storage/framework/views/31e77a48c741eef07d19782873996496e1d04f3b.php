<section>
    <div class="container winners-area" id="closedAuctionsRibon">
        <div class="row p-1">
            <div class="offers">
                CLOSED PRODUCTS
            </div>
        </div>
    </div>
</section><?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/closed-product-bar.blade.php ENDPATH**/ ?>