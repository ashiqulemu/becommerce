
<?php $__env->startSection('title-meta'); ?>
    <title>Buy Auction</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()): ?>
        <?php echo $__env->make('.site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


 <div class="container bg-white">
    <div class="row">
        <div class="col-lg-5">

            <div class="gallery pt-4">
                <?php $__currentLoopData = $item->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key==0): ?>
                        <div class="show"
                             href="<?php echo e(asset("storage/$media->image")); ?>" style="z-index: 1">

                            <img src="<?php echo e(asset("storage/$media->image")); ?>" alt=""
                                 id="show-img">
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="small-img">
                    <img src="/images/online_icon_right@2x.png"
                         class="icon-left" alt="" id="prev-img">
                    <div class="small-container">
                        <div id="small-img-roll">
                            <?php $__currentLoopData = $item->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(asset("storage/$media->image")); ?>"
                                     class="show-small-img" alt="">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <img src="/images/online_icon_right@2x.png"
                         class="icon-right" alt="" id="next-img">
                </div>
            </div>


        </div>
        <div class="col-lg-7 pr-0">
            <div class="buyAuctionRight">

                <div class="productTitle"><br>
                        <h4><?php echo e($item->product->name); ?></h4>
                        <h4><?php echo e($setting->amount_sign); ?><?php echo e($item->product->price); ?></h4>
                </div>

                    <article>
                        Buy now before the auction closes
                    </article>

                <div class="priceplan">
                    <div>
                        <span>value price</span>
                        <span><?php echo e($setting->amount_sign); ?><?php echo e($item->product->price); ?></span>
                    </div>
                    <div style="border-bottom: 1px solid black">
                       <span>Bid Credits Discount(<?php echo e($item->price_drop_percentage); ?>%)</span>
                        <span><?php echo e($setting->amount_sign); ?>

                            <?php echo e((($userBid*($item->cost_per_bid*10))*
                        $item->price_drop_percentage)/100); ?></span>
                    </div>
                    <div>

                        

                    </div>
                    <div>
                       <span>Buy now  price</span>
                        <span>
                            <?php echo e($setting->amount_sign); ?>

                            <?php echo e($item->product->price-
                            (($userBid*($item->cost_per_bid*10))*
                            $item->price_drop_percentage)/100); ?></span>
                    </div>
                </div>

                <form method="post" action="<?php echo e(url('/add-to-cart')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="product-quantity">
                        <input type="hidden" name="qty" value="1">
                        <input type="hidden" name="source" value="auction">
                        <input type="hidden"
                               name="price"
                               value="<?php echo e($item->product->price-
                            (($userBid*($item->cost_per_bid*10))*
                            $item->price_drop_percentage)/100); ?>">
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                    </div>
                    <button type="submit" class="buy-now">Buy Now</button>
                </form>

            </div>


        </div>
    </div>
     <div class="row">
            <div class="col-md-12 aucBuydescription pt-3">
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a data-toggle="tab" href="#home">Description</a></li>
                    

                </ul>
                <div class="tab-content">
                    <div id="home" class="tab-pane  fade in active">
                        <br>
                        <?php echo $item->description; ?>

                    </div>
                    
                        
                        
                    

            </div>
            </div>
     </div>
 </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/pages/product/auction-buy.blade.php ENDPATH**/ ?>