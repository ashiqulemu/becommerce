

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <br>
        <div class="row site-forms">
            <form method="post" action="<?php echo e(url('/admin/cms')); ?>">
                <?php echo csrf_field(); ?>
                <div class="">
                    <div class="form-box-header">
                        + Add Cms
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="">Cms Name</label>
                            <input class="form-control"
                                   name="name"
                                   type="text"
                                   required
                                   value="<?php echo e(old('name')); ?>"
                                   placeholder="Name">

                            <?php if($errors->has('name')): ?>
                                <div class="error"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="">Page Url <small>(after main url include back slash)</small></label>
                            <input  class="form-control"
                                   name="page_url"
                                   type="text"
                                    required
                                    value="<?php echo e(old('page_url')); ?>"
                                   placeholder="Page Url">

                            <?php if($errors->has('page_url')): ?>
                                <div class="error"><?php echo e($errors->first('page_url')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="">Section</label>
                            <select  class="form-control"
                                    name="section"
                                     required
                                    placeholder="Select Section">
                                <?php $__currentLoopData = ['Section 1','Section 2','Section 3','Section 4',
                'Section 5','Section 6','Section 7','Section 8', 'Section 9', 'Section 10']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item); ?>"> <?php echo e($item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('section')): ?>
                                <div class="error"><?php echo e($errors->first('section')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="">Title</label>
                            <input class="form-control"
                                   name="title"
                                   type="text"
                                   value="<?php echo e(old('title')); ?>"
                                   placeholder="Title">

                            <?php if($errors->has('title')): ?>
                                <div class="error"><?php echo e($errors->first('title')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="">Sub Title</label>
                            <input class="form-control"
                                   name="sub_title"
                                   type="text"
                                   value="<?php echo e(old('sub_title')); ?>"
                                   placeholder="Sub Title">

                            <?php if($errors->has('sub_title')): ?>
                                <div class="error"><?php echo e($errors->first('sub_title')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="">Content</label>
                            <textarea class="form-control"
                                      name="content"
                                      id="description">
                                <?php echo e(old('content')); ?>

                            </textarea>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group"><br>
                            <label for="">Status *</label><br>
                            <input type="radio" checked name="is_active" value="1" id="active"
                                   <?php if(!old('is_active')): ?> checked <?php endif; ?>
                                   <?php if(old('is_active') == '1'): ?> checked <?php endif; ?>
                            >
                            <label for="active">Active</label>

                            <input type="radio" name="is_active" value="0" id="inactive"
                                   <?php if(old('is_active') == '0'): ?> checked <?php endif; ?>
                            >
                            <label for="inactive">Inactive</label>
                            <?php if($errors->has('is_active')): ?>
                                <div class="error"><?php echo e($errors->first('is_active')); ?></div>
                            <?php endif; ?>
                        </div>

                    </div>

                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <button class="btn btn-primary ml-2" type="submit">submit</button>
                    </div>
                </div>
            </form>

        </div>

    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/cms/create.blade.php ENDPATH**/ ?>