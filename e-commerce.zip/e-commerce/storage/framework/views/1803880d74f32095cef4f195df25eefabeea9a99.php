
<?php $__env->startSection('title-meta'); ?>
    <title>Forgot Password</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()): ?>
        <?php echo $__env->make('site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

   <section class="forget-pass">
       <div class="container p-0">
           <div class="row bgArea">
               <div class="col-md-6"></div>
               <div class="col-md-6 px-5">
                   <?php if(session('status')): ?>
                       <div class="alert alert-success" role="alert">
                           <?php echo e(session('status')); ?>

                       </div>
                   <?php endif; ?>
                 <div class="password-right-content">
                        <h1>forgot password ?</h1>
                        <p>please enter your email address below</p>
                         <form method="post" class="mt-5" action="<?php echo e(route('password.email')); ?>">
                             <?php echo csrf_field(); ?>
                             <input type="email"
                                    placeholder="Enter your email address"
                                    name="email"
                                    value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus
                                    class="form-control">

                             <?php if($errors->has('email')): ?>
                                 <span class="text-danger">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                             <?php endif; ?>

                             <button class="button-global" type="submit">Submit</button>
                             <a href="<?php echo e(url('/#login-area')); ?>"
                                class="button-global"
                                style="padding: 10px; background: rgb(247, 247, 247)"
                             >Login</a>
                         </form>
                 </div>
               </div>
           </div>
       </div>
   </section>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    
    
    
    
    

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/login/login-partitial/forget-password.blade.php ENDPATH**/ ?>