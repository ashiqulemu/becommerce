
<?php $__env->startSection('title-meta'); ?>
    <title>Credit Buy History </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('.site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('.site.login.login-partitial.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="myFirebidder">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>My Firebidders</h2>
                    <hr>
                </div>
                <div class="col-lg-3">
                    <?php $__env->startComponent('site.login.user.components.leftBar'); ?> <?php echo $__env->renderComponent(); ?>
                </div>
                <div class="col-lg-9 p-0">
                    <div class="userDetailsArea">
                        <h4 class="text-capitalize pb-3">Credit Buy History</h4>
                        <table class="table-striped table text-capitalize">
                            <thead>
                            <tr>
                                <th>Order No</th>
                                <th>Amount</th>
                                <th>Credit</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($creditHistory)): ?>
                                <?php $__currentLoopData = $creditHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <a href="<?php echo e('/generate-invoice/'.$history->id); ?>">
                                                #<?php echo e($history->order_no); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <?php echo e($setting->amount_sign); ?>

                                            <?php echo e($history->amount); ?>

                                        </td>
                                        <td> <?php echo e($history->credit); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3"> No credit buy history found.</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($creditHistory->links()); ?>

                    </div>
                </div>
            </div>

        </div>
        </div>
    </section>
    <?php $__env->startComponent('site.login.user.components.user-sub-footer'); ?> <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/login/user/partial/credit-buying-history.blade.php ENDPATH**/ ?>