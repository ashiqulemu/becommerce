<section id="live-auctions">
    <div class="container auction-products-area">
        <div class="row mx-auto">

            <?php $__currentLoopData = $upCommingAuction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="products">
                    <div class="product-head default-a">
                        <a href="<?php echo e(url('auction/details/'.$upItem->id).'/'.$upItem->name); ?>">
                        <div><?php echo e($upItem->name); ?></div>
                        <div>RRP $<?php echo e($upItem->product->price); ?></div>
                        </a>



                    </div>
                    <a href="<?php echo e(url('auction/details/'.$upItem->id).'/'.$upItem->name); ?>">
                    <div class="photo">
                        <?php $__currentLoopData = $upItem->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($key==0): ?>
                                <img src="<?php echo e(asset("storage/$media->image")); ?>" alt=""
                                     class="img-fluid d-block">
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    </a>
                    <div class="stars align-items-center justify-content-end d-flex">

                        <?php echo e($upItem->cost_per_bid); ?> x  <i class="fa fa-star"></i>

                    </div>

                    <div class="bottom-box">
                        <div id="<?php echo e('countDownValue'.$upItem->id); ?>" v-show="false"><?php echo e($upItem->up_time); ?>

                        </div>

                        <div v-show="false">
                            {{ countDown(<?php echo '\''.$upItem->id.'\','.'\''.$upItem->up_time.'\''; ?>) }}
                        </div>

                        <div class="pl-2">
                             $<?php echo e(number_format((float)$upItem->starting_price, 2, '.', '')); ?>

                        </div>

                         <div id="<?php echo e('getting-started'.$upItem->id); ?>"> </div>

                        <div>
                            <button type="button">
                                <img src="/images/home/reminder.png">
                            </button>
                       </div>

                </div>
            </div>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
    </div>

</section><?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/up-coming-auction.blade.php ENDPATH**/ ?>