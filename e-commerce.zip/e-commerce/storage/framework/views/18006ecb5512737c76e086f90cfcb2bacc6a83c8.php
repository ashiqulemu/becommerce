<section id="winners">
    <div class="container winners-area">
        <div class="row p-1">
            <div class="offers">
                WINNERS
            </div>
        </div>
        <div class="row winners-people mx-auto">
            <div class="col-lg-4 ">
                <div class="photo">
                    <img src="/images/home/winner-man.jpg" class="w-100 img-fluid d-block" >
                </div>
            </div>
            <div class="col-lg-4">
                <div class="photo">
                    <img src="/images/home/winner-man.jpg" class="w-100 img-fluid d-block" >
                </div>
            </div>
            <div class="col-lg-4">
                <div class="photo">
                    <img src="/images/home/winner-man.jpg" class="w-100 img-fluid d-block" >
                </div>
            </div>
            <div class="col-lg-4 ">
                <div class="photo">
                    <img src="/images/home/winner-man.jpg" class="w-100 img-fluid d-block" >
                </div>
            </div>
            <div class="col-lg-4">
                <div class="photo">
                    <img src="/images/home/winner-man.jpg" class="w-100 img-fluid d-block" >
                </div>
            </div>
            <div class="col-lg-4">
                <div class="photo">
                    <img src="/images/home/winner-man.jpg" class="w-100 img-fluid d-block" >
                </div>
            </div>

        </div>
    </div>
</section><?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/winners.blade.php ENDPATH**/ ?>