
<?php $__env->startSection('title-meta'); ?>
    <title>Firebidder user loged </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.login.login-partitial.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="myFirebidder">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>My Firebidders</h2>
                    <hr>
                </div>
                <div class="col-lg-3">
                    <?php $__env->startComponent('site.login.user.components.leftBar'); ?> <?php echo $__env->renderComponent(); ?>
                </div>
                <div class="col-lg-9 p-0">

                  <div class="userDetailsArea">
                      <a href="<?php echo e(url('/user-details/settings')); ?>"
                         class="float-right text-right btn btn-warning text-dark">Edit Info</a>
                      <h4 class="text-capitalize pb-3">
                          <span>My Information</span>
                      </h4>
                      <table class="table-striped table text-capitalize">
                          <tr>
                              <td> Name</td>
                              <td>: <?php echo e(auth()->user()->name); ?> </td>
                          </tr>
                          <tr>
                              <td> Email</td>
                              <td>: <?php echo e(auth()->user()->email); ?> </td>
                          </tr>
                          <tr>
                              <td> Mobile</td>
                              <td> : <?php echo e(auth()->user()->contact ? auth()->user()->contact->mobile : ''); ?> </td>
                          </tr>
                          <tr>
                              <td> Address</td>
                              <td> : <?php echo e(auth()->user()->contact ? auth()->user()->contact->address : ''); ?> </td>
                          </tr>
                          <tr>
                              <td> post code</td>
                              <td> : <?php echo e(auth()->user()->contact ? auth()->user()->contact->post_code : ''); ?></td>
                          </tr>
                          <tr>
                              <td> city</td>
                              <td> : <?php echo e(auth()->user()->contact ? auth()->user()->contact->city : ''); ?> </td>
                          </tr>
                          <tr>
                              <td> District</td>
                              <td> : <?php echo e(auth()->user()->contact ? auth()->user()->contact->district : ''); ?></td>
                          </tr>

                      </table>
                  </div>

                </div>
            </div>
        </div>
        </div>
    </section>
    <?php $__env->startComponent('site.login.user.components.user-sub-footer'); ?> <?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/login/user/user.blade.php ENDPATH**/ ?>