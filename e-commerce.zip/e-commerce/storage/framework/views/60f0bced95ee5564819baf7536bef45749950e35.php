

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <br>
        <div class="main-content container-fluid"></div>
        <div class="row site-forms">
            <form method="post" action="<?php echo e(url('/admin/promotion')); ?>">
                <?php echo csrf_field(); ?>
                <div class="">
                    <div class="form-box-header">
                        + Add Promotion
                    </div>
                </div>

                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="">Code</label>
                            <input class="form-control"
                                   name="code" type="text"
                                   placeholder="Enter Code" required>
                            <?php if($errors->has('code')): ?>
                                <div class="error"><?php echo e($errors->first('code')); ?></div>
                            <?php endif; ?>

                        </div>

                    </div>
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="">Value</label>
                            <input  type ="number"
                                    name="amount"
                                    step="any"
                                    class="form-control"
                                    placeholder="Enter Amount" required>
                            <?php if($errors->has('amount')): ?>
                                <div class="error"><?php echo e($errors->first('amount')); ?></div>
                            <?php endif; ?>

                        </div>
                    </div>

                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="">Sign</label>
                            <select class="js-example-basic-multiple form-control"
                                    name="sign" required>
                                <option value="">Select Option</option>
                                    <option value="Percentage">Percentage</option>
                                    <option value="Amount">Amount</option>
                            </select>
                            <?php if($errors->has('sign')): ?>
                                <div class="error"><?php echo e($errors->first('sign')); ?></div>
                            <?php endif; ?>

                        </div>
                    </div>
                <div class="col-lg-3">
                    <div class="form-group">
                        <label for="">At Least Price</label>
                        <input  type ="number"
                                name="at_least_amount"
                                step="any"
                                class="form-control"
                                placeholder="Enter Amount" required>
                        <?php if($errors->has('at_least_amount')): ?>
                            <div class="error"><?php echo e($errors->first('at_least_amount')); ?></div>
                        <?php endif; ?>

                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <button class="btn btn-primary ml-2" type="submit">submit</button>
                    </div>
                </div>
            </form>

        </div>

    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/promotion/createPromotion.blade.php ENDPATH**/ ?>