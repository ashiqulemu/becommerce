
<?php $__env->startSection('title-meta'); ?>
    <title>Product Details</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()): ?>
        <?php echo $__env->make('.site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <section>
        <div class="container">
            <?php if(auth()->user()): ?>
                <div class="row ">
                    <div class="partners">
                        <a href="/user-home##auctionProductRibon" class="section-links">Live Auctions</a>
                        <a href="/user-home#upcoming-auctionsRibon" class="section-links">Upcoming Auctions</a>
                        <a href="/user-home#closedAuctionsRibon" class="section-links">Closed Auctions</a>
                        <a href="/all-products" class="section-links">Regular product</a>
                        <a href="/how-it-works" class="section-links">How it works</a>
                    </div>
                </div>
            <?php endif; ?>
            <div class="row bg-white">
                <div class="col-md-8  row w-100">
                    <div class="col-lg-7 bg-white  pt-2">
                        <div class="gallery product">
                            <?php $__currentLoopData = $item->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key==0): ?>
                                    <div class="show"
                                         href="<?php echo e(asset("storage/$media->image")); ?>" style="z-index: 1">

                                        <img src="<?php echo e(asset("storage/$media->image")); ?>" alt=""
                                             id="show-img">
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="small-img">
                                <img src="/images/online_icon_right@2x.png"
                                     class="icon-left" alt="" id="prev-img">
                                <div class="small-container">
                                    <div id="small-img-roll">
                                        <?php $__currentLoopData = $item->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img src="<?php echo e(asset("storage/$media->image")); ?>"
                                                 class="show-small-img" alt="">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <img src="/images/online_icon_right@2x.png"
                                     class="icon-right" alt="" id="next-img">
                            </div>
                        </div>
                        
                        
                        
                        
                        

                        

                        


                    </div>
                    <div class="col-lg-5 bg-white pt-2">
                        <div class="product-varient mt-5">
                            <div class="product-title"><?php echo e($item->name); ?></div>
                            <div class="product-price">Price: <span><?php echo e($setting->amount_sign); ?><?php echo e($item->price); ?></span>
                            </div>
                            <form method="post" action="<?php echo e(url('/add-to-cart')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="product-quantity">
                                    <span>quantity:</span>
                                    <input type="text" name="qty" min="1" value="1">
                                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                </div>
                                <button type="submit" class="cart">add to cart</button>
                            </form>
                        </div>
                    </div>
                    <div class=" p-0 col-md-12">
                        <div class="product_details">
                            <div class="productDescription p-3">
                                <br>
                                <ul class="nav nav-tabs" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-toggle="tab" href="#home">Description</a>
                                    </li>
                                </ul>
                                <!-- Tab panes -->
                                <div class="tab-content">
                                    <div id="home" class="container tab-pane active pt-3 pb-3">
                                        <?php echo $item->description; ?>

                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 ml-5 bg-white p-0 pt-2 pr-2">
                    <div class="your-basket  mt-3">
                        <header>
                            your basket
                        </header>
                        <article>
                            <div class="max-input">
                                <table class="product-list">
                                    <?php
                                        $count=1;
                                        $subTotal=0;
                                    ?>
                                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($count); ?>. <?php echo e($item->name); ?></td>
                                            <td>
                                                <input type="number"
                                                       min="1"
                                                       onchange="setCartUpdateUrl(<?php echo e($item->id.",'".$item->rowId."'"); ?>)"
                                                       onkeyup="setCartUpdateUrl(<?php echo e($item->id.",'".$item->rowId."'"); ?>)"
                                                       id="cartQuantity<?php echo e($item->id); ?>"
                                                       disabled
                                                       value="<?php echo e($item->qty); ?>"
                                                       style="width: 40px">

                                            </td>
                                            <td><?php echo e($setting->amount_sign); ?><?php echo e($item->price); ?></td>
                                            <td><?php echo e($setting->amount_sign); ?><?php echo e($item->price*$item->qty); ?></td>
                                            <td>
                                                <i class="fa fa-edit"
                                                   title="Edit"
                                                   onclick="editCartItem(<?php echo e($item->id.",'".$item->rowId."'"); ?>)"
                                                   id="cartEditBtn<?php echo e($item->id); ?>">

                                                </i>
                                                <a href="#" id="cartUpdateUrl<?php echo e($item->id); ?>">
                                                    <i class="fa fa-check"
                                                       title="Update"
                                                       id="cartUpdateBtn<?php echo e($item->id); ?>"
                                                       style="display: none">

                                                    </i>
                                                </a>
                                                <a href="<?php echo e(url('/delete/cart-item/'.$item->rowId)); ?>">
                                                    <i class="fa fa-trash text-danger" title="Delete"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                            $count++;
                                             $subTotal+=$item->price*$item->qty;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>

                            <table class="additional-list">
                                <tr>
                                    <td>
                                        Promo Code
                                    </td>
                                    <td>
                                        <div class="promoSection">
                                            <input type="text"
                                                   onchange="setPromoLink(<?php echo e($item->id.",'".$item->name."'"); ?>)"
                                                   onkeyup="setPromoLink(<?php echo e($item->id.",'".$item->name."'"); ?>)"
                                                   class="promo"
                                                   required
                                                   id="promoInput"
                                            >
                                            <a href="#" id="promoLink"
                                               class="btn btn-sm btn-warning use-btn"
                                            >use</a>
                                        </div>

                                    </td>

                                </tr>
                                <tr>
                                    <td>Sub total</td>
                                    <td><?php echo e($setting->amount_sign); ?><?php echo e($subTotal); ?></td>
                                </tr>
                                <?php if(count($cartItems)): ?>
                                    <tr>
                                        <td>(+) Delivery cost</td>
                                        <?php if($shippingCost): ?>
                                            <td><?php echo e($setting->amount_sign); ?><?php echo e($shippingCost->amount); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($setting->amount_sign); ?>0</td>
                                        <?php endif; ?>
                                    </tr>
                                <?php else: ?>
                                    <tr>
                                        <td>(+) Delivery cost</td>
                                        <td><?php echo e($setting->amount_sign); ?>0</td>
                                    </tr>
                                <?php endif; ?>
                                <tr>
                                    <?php if($promotion): ?>

                                        <td>(-) Discount <?php echo e($promotion->sign=='Percentage'?
                                        '('.$promotion->amount.'%)':''); ?></td>
                                        <?php if($promotion->sign=='Percentage'): ?>
                                            <?php
                                                $discountAmount=($subTotal*
                                            $promotion->amount)/100
                                            ?>
                                            <td><?php echo e($setting->amount_sign); ?><?php echo e($discountAmount); ?></td>
                                        <?php else: ?>
                                            <?php
                                                $discountAmount=$promotion->amount
                                            ?>
                                            <td><?php echo e($setting->amount_sign); ?><?php echo e($promotion->amount); ?></td>
                                        <?php endif; ?>

                                    <?php else: ?>
                                        <?php
                                            $discountAmount=0
                                        ?>
                                        <td>(-) Discount</td>
                                        <td><?php echo e($setting->amount_sign); ?>0</td>
                                    <?php endif; ?>

                                </tr>
                                <?php if(count($cartItems)): ?>
                                    <tr>
                                        <td>Grand total</td>
                                        <?php if($shippingCost): ?>
                                            <?php if($promotion): ?>
                                                <td>
                                                    <?php echo e($setting->amount_sign); ?><?php echo e(($subTotal+$shippingCost->amount)
                                                    -$discountAmount); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e($setting->amount_sign); ?><?php echo e($subTotal+$shippingCost->amount); ?></td>
                                            <?php endif; ?>

                                        <?php else: ?>
                                            <td><?php echo e($setting->amount_sign); ?><?php echo e($subTotal); ?></td>
                                        <?php endif; ?>
                                    </tr>
                                <?php else: ?>
                                    <tr>
                                        <td>Grand total</td>
                                        <td><?php echo e($setting->amount_sign); ?><?php echo e($subTotal); ?></td>
                                    </tr>
                                <?php endif; ?>
                            </table>

                        </article>

                        <footer>
                            <?php if(request()->input('pcode')): ?>
                                <a href="<?php echo e(url('/payment-confirmation?pcode='.request()->
                                input('pcode'))); ?>"
                                   class="checkout"
                                   style="margin-bottom: 5px;
                                   text-decoration: none">go to checkout</a>
                            <?php else: ?>
                                <a href="<?php echo e(url('/payment-confirmation')); ?>"
                                   class="checkout"
                                   style="margin-bottom: 5px;
                                   text-decoration: none">go to checkout</a>
                            <?php endif; ?>

                            <a href="<?php echo e(url('/all-products')); ?>"
                               class="checkout shopping" style="text-decoration: none">Continue
                                Shopping!</a>

                        </footer>
                    </div>
                </div>
            </div>

        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        function setPromoLink(id, name) {
            var val = $('#promoInput').val()
            $('#promoLink').attr('href', '/product/details/' + id + '/' + name + '?pcode=' + val)
        }

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/pages/product/product-details.blade.php ENDPATH**/ ?>