
<?php $__env->startSection('title-meta'); ?>
    <title>Auction Details</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()): ?>
    <?php echo $__env->make('.site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <section class="">
        <div class="container product-details">
            <?php if(auth()->user()): ?>
            <div class="row ">
                <div class="partners">
                    <a href="/user-home##auctionProductRibon" class="section-links">Live Auctions</a>
                    <a href="/user-home#upcoming-auctionsRibon" class="section-links">Upcoming Auctions</a>
                    <a href="/user-home#closedAuctionsRibon" class="section-links">Closed Auctions</a>
                    <a href="/all-products" class="section-links">Regular product</a>
                    <a href="/how-it-works" class="section-links">How it works</a>
                </div>
            </div>
            <?php endif; ?>
            <div class="row ">
                <div class="col-lg-6 pr-0">
                    <div class="gallery">
                            <h4 class="product_name"><?php echo e($item->name); ?></h4>
                             <h5 class="product_price">$ <?php echo e($item->product->price); ?></h5>
                        <hr>

                        <?php $__currentLoopData = $item->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($key==0): ?>
                                <div class="show"
                                     href="<?php echo e(asset("storage/$media->image")); ?>" style="z-index: 1">

                                    <img src="<?php echo e(asset("storage/$media->image")); ?>" alt=""
                                         id="show-img">
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="gallery-star">
                            <div><?php echo e($item->cost_per_bid); ?> x
                                <i class="fa fa-star"></i></div>
                        </div>

                        <div class="small-img">
                            <img src="/images/online_icon_right@2x.png"
                                 class="icon-left" alt="" id="prev-img">
                            <div class="small-container">
                                <div id="small-img-roll">
                                    <?php $__currentLoopData = $item->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset("storage/$media->image")); ?>"
                                             class="show-small-img" alt="">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <img src="/images/online_icon_right@2x.png"
                                 class="icon-right" alt="" id="next-img">
                        </div>
                    </div>

                </div>
                <auction-slots-single></auction-slots-single>
            </div>

            <div class="row">
                <div class="col-lg-12 product_details">
                    <div class="productDescription p-3">
                        <br>
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#home">Description</a>
                            </li>
                            
                            
                            

                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div id="home" class="container tab-pane active pt-3">
                                <?php echo $item->description; ?>

                            </div>

                            
                            
                            
                            

                            
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/pages/product/productDetails.blade.php ENDPATH**/ ?>