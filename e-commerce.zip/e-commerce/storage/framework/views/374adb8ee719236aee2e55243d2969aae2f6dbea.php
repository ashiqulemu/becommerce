<section>
    <div class="container winners-area" id="upcoming-auctionsRibon">
        <div class="row p-1">
            <div class="offers">
                UPCOMING AUCTIONS
            </div>
        </div>
    </div>
</section><?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/up-coming-auction-bar.blade.php ENDPATH**/ ?>