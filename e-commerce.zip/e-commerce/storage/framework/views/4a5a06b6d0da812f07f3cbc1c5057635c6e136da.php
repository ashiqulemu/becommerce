<section class="site-header" v-if="regularHeader">

    <?php if(!auth()->user()): ?>
        <div class="container">
            <div class="row bg-white">
                <div class="col-lg-4 pr-0">
                    <div class="brand">
                        <a href="<?php echo e(url('/')); ?>">
                            <img src="/images/site-logo.png" class="img-fluid d-block" alt="">
                        </a>
                    </div>
                </div>

                <div class="col-lg-5">
                    <?php if(!($uri === 'forget-password' || strpos($uri, 'password/reset'))): ?>
                    <form method="POST" action="<?php echo e(url('/admin/login')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>
                        <div class="authPanel" id="login-area">
                            <div class="loged_area">
                                <div>
                                        <input id="login"
                                               type="text"
                                               class="form-control<?php echo e($errors->has('username') ||
                                               $errors->has('email') ? ' is-invalid' : ''); ?>"
                                               placeholder="Username or email"
                                               name="login" value="<?php echo e(old('username') ?: old('email')); ?>" required autofocus>
                                        <?php if($errors->has('username') || $errors->has('email')): ?>
                                            <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('username') ?:
                                    $errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>


                                    
                                           
                                           
                                           
                                           
                                           
                                           
                                           
                                    
                                    
                                        
                                    
                                    

                                </div>
                                <div>

                                    <input id="password"
                                           type="password"
                                           class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid
                                               <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="password"
                                           required
                                           autocomplete="current-password"
                                           placeholder="Password">

                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <div class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    <input type="hidden" name="from" value="st">

                                </div>
                                <div>
                                    <div class="form-group mb-2 flex-column">
                                        <button type="submit" class="btn  login  ">Login</button>
                                    </div>
                                </div>
                            </div>
                            <div class="middle-bottom">
                                <div>
                                    Forgot password? <a href="<?php echo e(url('/forget-password')); ?>">Click Here</a>
                                </div>
                                <div>
                                    New? <a href="/#sign-up">Sign Up</a>
                                </div>
                            </div>
                        </div>

                    </form>

                    <?php endif; ?>
                </div>

                <div class="col-lg-3">
                    <div class="social">
                        <div class="mb-3 homeCart">
                            <a href="/view-cart" title="view shopping cart" class="shoppingCart">
                                <i class="fa fa-cart-arrow-down"  ></i>
                                <div class="counter"><?php echo e(Cart::content()->count()); ?></div>
                            </a>
                        </div>
                        <div class="links">
                            
                                
                                
                            
                            
                                
                            
                            
                                
                            
                            <?php if(auth()->user()): ?>
                                <div>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                          style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row ">
                <div class="partners">
                    <a href="/#auctionProductRibon" class="section-links">Live Auctions</a>
                    <a href="/#upcoming-auctionsRibon" class="section-links">Upcoming Auctions</a>
                    <a href="/#closedAuctionsRibon" class="section-links">Closed Auctions</a>
                    <a href="<?php echo e(url('/all-products')); ?>" class="section-links">Regular product</a>
                    <a href="<?php echo e(url('/how-it-works')); ?>" class="section-links">How it works</a>

                </div>

            </div>

        </div>

    <?php endif; ?>




</section>

<?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/header.blade.php ENDPATH**/ ?>