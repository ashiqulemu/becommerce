

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <br>
        <div class="row site-forms">
            <form method="post" action="<?php echo e(url('/admin/auction/'.$auction->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <div class="">
                    <div class="form-box-header">
                        Update Auction
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Product *</label>

                            <select class="js-example-basic-multiple form-control"
                                    name="product_id" id="select1">
                                <option value="">Select Product</option>

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"
                                    <?php if(old('product_id', $auction->product_id) == $item->id): ?> <?php echo e('selected'); ?> <?php endif; ?>>
                                        <?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('product_id')): ?>
                                <div class="error"><?php echo e($errors->first('product_id')); ?></div>
                            <?php endif; ?>

                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="form-group">
                            <label for="">Name *</label>
                            <input
                                    class="form-control"
                                    name="name"
                                    type="text"
                                    placeholder="name"
                                    value="<?php echo e(old('name',$auction->name)); ?>"
                            >

                            <?php if($errors->has('name')): ?>
                                <div class="error"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
                <div class="col-md-12">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Auction Type *</label>
                            <select class="js-example-basic-multiple form-control"
                                    name="auction_type" id="select1">
                                <option value=""><?php echo e($auction->auction_type); ?></option>
                                <option value="Paid"
                                <?php if(old('auction_type', $auction->auction_type) == 'Paid'): ?> <?php echo e('selected'); ?> <?php endif; ?>>Paid</option>

                                <option value="Free"
                                <?php if(old('auction_type', $auction->auction_type) == 'Free'): ?> <?php echo e('selected'); ?> <?php endif; ?>>Free</option>

                            </select>
                            <?php if($errors->has('auction_type')): ?>
                                <div class="error"><?php echo e($errors->first('auction_type')); ?></div>
                            <?php endif; ?>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Starting Price *</label>
                            <input
                                    class="form-control"
                                    name="starting_price"
                                    type="number"
                                    step="any"
                                    value="<?php echo e(old('starting_price', $auction->starting_price)); ?>"
                                    placeholder="Price">

                            <?php if($errors->has('starting_price')): ?>
                                <div class="error"><?php echo e($errors->first('starting_price')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Cost Per Bid *</label>
                            <input
                                    class="form-control"
                                    name="cost_per_bid"
                                    type="number"
                                    step="any"
                                    value="<?php echo e(old('cost_per_bid', $auction->cost_per_bid)); ?>"
                                    placeholder="Cost Per Bid">

                            <?php if($errors->has('cost_per_bid')): ?>
                                <div class="error"><?php echo e($errors->first('cost_per_bid')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Price increase every bid *</label>
                            <input
                                    class="form-control"
                                    name="price_increase_every_bid"
                                    type="number"
                                    step="any"
                                    value="<?php echo e(old('price_increase_every_bid', $auction->price_increase_every_bid)); ?>"
                                    placeholder="Price increase every bid">

                            <?php if($errors->has('price_increase_every_bid')): ?>
                                <div class="error"><?php echo e($errors->first('price_increase_every_bid')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Price drop percentage </label>
                            <input
                                    class="form-control"
                                    name="price_drop_percentage"
                                    type="number"
                                    step="any"
                                    value="<?php echo e(old('price_drop_percentage', $auction->price_drop_percentage)); ?>"
                                    placeholder="Price drop percentage">

                            <?php if($errors->has('price_drop_percentage')): ?>
                                <div class="error"><?php echo e($errors->first('price_drop_percentage')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Description</label>
                            <textarea name="description" id="description"><?php echo e(old('description', $auction->description)); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Up Time</label>
                            <input type="text"
                                   id="datetimepicker"
                                   name="up_time"
                                   class="form-control"
                                   value="<?php echo e(old('up_time', $auction->up_time)); ?>"
                                   placeholder="Set Up Time"
                            />
                        </div>
                    </div>
                    <div class="col-md-6" style="display: none">
                        <div class="form-group">
                            <label for="">Duration Time</label>
                            <input
                                    class="form-control"
                                    name="duration_time_range"
                                    id="durationtimepicker"
                                    type="text"
                                    value="<?php echo e(old('duration_time_range', $auction->duration_time_range)); ?>"
                                    placeholder="Set Duration Time">
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                            <label for="">Slot range and Time range</label>

                            <?php if(count($auction->slots)): ?>
                                {{ initialSlotRange(<?php echo '\''.$auction->slots.'\''; ?>) }}
                            <?php endif; ?>
                            <div class="slot-range" v-for="(item,index) in slotRangeData" :key="index">
                                <input type="number"

                                       v-model="item.slot_number"
                                       @keyup="getSlotRage(item.slot_number,index)"
                                       name="slot_number[]" class="form-control"

                                >

                                <input type="text"
                                       v-model="item.slotRange"
                                       disabled readonly
                                       class="form-control">
                                <input type="text"
                                       class="form-control"
                                       :id="'slotDuration'+index"
                                       @click="getSlotDurationDate(index)"
                                       name="duration_time[]">

                                <button class="btn btn-primary btn-sm" style="margin-right:3px "
                                        @click.prevent="addRow()" v-if="index==0"   title="Add More">+</button>
                                <button class="btn btn-danger btn-sm "  @click.prevent="removeRow()"
                                        v-if="index==slotRangeData.length-1" title="Delete This Row">x</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Auction Image</label>
                            <input type="file" class="form-control" name="images[]" accept="image/*" multiple>
                        </div>
                        <div>
                            <?php if(count($auction->medias)): ?>
                                <div class="product-image-container">
                                    <?php $__currentLoopData = $auction->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="image-box">
                                            <img src="<?php echo e(asset("storage/$media->image")); ?>" alt="">
                                            <label class="check-product">
                                                <input type="checkbox" name="deleted_images[]" value="<?php echo e($media->id); ?>" checked/>
                                                <span><i class="fa fa-times"></i></span>
                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4"><br>

                        <div class="form-group">
                            <div v-if="statusShow == true">
                                {{ setStatus(<?php echo '\''.$auction->status.'\''; ?>) }}
                            </div>



                            <label for="">Status *</label><br>
                            <input type="radio"
                                   name="status"
                                   value="Active" id="active"
                                    v-model="status"
                                   @input="setStatus('Active')"
                            >
                            <label for="active">Active</label>

                            
                                   
                                   
                                   
                                   
                                   
                            
                            

                            <input type="radio"
                                   name="status"
                                   value="Inactive"
                                   id="inactive"
                                   v-model="status"
                                   @input="setStatus('inactive')"
                            >
                            <label for="inactive">Inactive</label>
                            <?php if($errors->has('status')): ?>
                                <div class="error"><?php echo e($errors->first('status')); ?></div>
                            <?php endif; ?>
                        </div>

                    </div>













                </div>
                <div class="col-md-12">
                    <div class="form-group">

                        <button class="btn btn-primary ml-2" type="submit">submit</button>
                    </div>
                </div>
            </form>

        </div>

    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/auction/edit.blade.php ENDPATH**/ ?>