<section id="sign-up">
    <div class="container signup-area">
        <div class="row">
            <div class="col-lg-6">
                <div class="video">

                    <video width="100%" height="100%" controls>
                        <source src="/video/ruth-lorenzo-knocking-on-heavens-door-x-factor-08-11-2008-safe-and-through-to-the-next-round-flv.mp4" type="video/mp4">
                    </video>

                    
                            
                            
                            
                            
                </div>
            </div>
            <div class="col-lg-6">
                <div class="sign-up">
                    <div class="header">
                        <img src="/images/home/free-sign-up.png" width="70px">
                        Sign-up takes less than 30 seconds
                    </div>
                    <div class="content">
                        <form class="form-horizontal manipulate" method="POST" action="<?php echo e(url('/admin/register')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group position-relative">
                                <label for="sign_username">Username:</label>
                                <div class="d-flex flex-column w-100">
                                    <input id="sign_username" type="text"
                                           class="form-control <?php if ($errors->has('sign_username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sign_username'); ?> is-invalid
                                       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="sign_username" value="<?php echo e(old('sign_username')); ?>"
                                           required autocomplete="sign_username">
                                    <?php if ($errors->has('sign_username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sign_username'); ?>
                                    <div class="invalid-feedback text-right" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>

                            <div class="form-group position-relative">
                                    <label for="sign_up_password">Password:</label>
                                   <div class="d-flex flex-column w-100">
                                       <input id="sign_up_password" type="password"
                                              class="form-control <?php if ($errors->has('sign_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sign_password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                              name="sign_password" required autocomplete="new-password">

                                       <?php if ($errors->has('sign_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sign_password'); ?>
                                       <div class="invalid-feedback text-right" role="alert">
                                           <strong><?php echo e($message); ?></strong>
                                       </div>
                                       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                   </div>
                            </div>
                            <div class="form-group position-relative">
                                <label for="sign_up_email">Email:</label>
                                <div class="d-flex flex-column w-100">
                                    <input id="sign_up_email" type="email"
                                           class="form-control <?php if ($errors->has('sign_email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sign_email'); ?> is-invalid
                                       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="sign_email" value="<?php echo e(old('sign_email')); ?>"
                                           required autocomplete="sign_email">
                                    <?php if ($errors->has('sign_email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sign_email'); ?>
                                    <div class="invalid-feedback text-right" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>



                            
                                
                                
                                       
                                       
                                       
                            

                            <div class="form-group">
                                <label   for="pwd">Mobile:</label>
                                <input type="number" class="form-control" name="mobile"
                                       value="<?php echo e(old('moible')); ?>">
                            </div>
                            <input  type="hidden" name="name" value="user" >

                            <div class="checkbox d-flex">
                                <label for=""></label>
                                <label><input type="checkbox"
                                              v-model="termCheck" @input="changeTerm"> &nbsp;
                                    I Accept the <a href="/terms-and-conditions" style="color:#FFA134;">Terms and Conditions</a> and   <a style="color:#FFA134;" href="/privacy-policy">Privacy
                                    Policy</a> of Firebidders.com.
                                </label>
                            </div>
                            <div class="form-group">
                                <label for="pwd"> </label>
                                <button type="submit"
                                        class="btn btn-success btn-block"
                                        :disabled="!termCheck">
                                    Sign-up and start saving
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/signUp.blade.php ENDPATH**/ ?>