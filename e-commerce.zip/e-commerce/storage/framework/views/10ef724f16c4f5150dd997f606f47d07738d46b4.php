
<?php $__env->startSection('title-meta'); ?>
    <title>Firebidder user loged </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('.site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('.site.login.login-partitial.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="myFirebidder">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>My Firebidders</h2>
                    <hr>
                </div>
                <div class="col-lg-3">
                    <?php $__env->startComponent('site.login.user.components.leftBar'); ?> <?php echo $__env->renderComponent(); ?>
                </div>
                <div class="col-lg-9 p-0">

                    <div class="userDetailsArea">
                        <h4 class="text-capitalize pb-3">My Referrals</h4>
                        <table class="table-striped table">
                            <tr>
                                <td>Referral url</td>
                                <td>http://www.billboardbd.com/?ref=20100<?php echo e(auth()->user()->id); ?></td>
                            </tr>
                            <tr>
                                <td> Referred User</td>
                                <td><?php echo e($referCount); ?></td>
                            </tr>
                        </table>
                        <p>Click <a href="<?php echo e(url('/user-details/referral-friend')); ?>">here</a> to refer a friend now</p>
                    </div>
                </div>
            </div>

        </div>
        </div>
    </section>
    <?php $__env->startComponent('site.login.user.components.user-sub-footer'); ?> <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/login/user/partial/refferal.blade.php ENDPATH**/ ?>