

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <p class="pageTitle">
                    <i class="fa fa-cogs"></i>  manage Promotion
                </p>
            </div>
            <div class="col-md-12">
                <div class="overflow">
                    <table class="table table-striped  table-bordered table-hover" id="manageTable">
                        <thead>
                        <tr>
                            <th>SL </th>
                            <th>Code</th>
                            <th>Value</th>
                            <th>Sign</th>
                            <th>At Least Amount</th>
                            <th>Action</th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($promo->code); ?></td>
                                <td><?php echo e($promo->amount); ?></td>
                                <td><?php echo e($promo->sign); ?></td>
                                <td><?php echo e($promo->at_least_amount); ?></td>


                                <td>
                                    <div>
                                        <a href="<?php echo e(url('/admin/promotion/'.$promo->id).'/edit'); ?>" title="Edit">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <a  href="#"
                                            @click.prevent="deleteMe('<?php echo e('/admin/promotion/'.$promo->id); ?>')" title="Delete">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/promotion/managePromotion.blade.php ENDPATH**/ ?>