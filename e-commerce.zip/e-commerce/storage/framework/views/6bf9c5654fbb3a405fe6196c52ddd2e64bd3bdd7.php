
<?php $__env->startSection('title-meta'); ?>
    <title>404-Unknown Request</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()): ?>
        <?php echo $__env->make('site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <section class="error-404">
        <div class="container p-0">
            <div class="errorPage">
                <div class="inerItem">
                    <div class="error_404">404</div>

                    <div class="mainText">
                        <br>Oops!<br>Something Wrong
                        <h6>Uh Oh! Looks like some Typing mistake</h6>
                        <a href="/" class="link-to-home">
                           Take Me Away!
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    
    
    
    
    

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/errors/404.blade.php ENDPATH**/ ?>