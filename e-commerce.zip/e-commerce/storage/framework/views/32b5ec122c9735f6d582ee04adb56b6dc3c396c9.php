

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <br>
        <div class="main-content container-fluid"></div>
        <div class="row site-forms">
            <form method="post" action="<?php echo e(url('/admin/package')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="">
                    <div class="form-box-header">
                        + Add Package
                    </div>
                </div>

                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="">Name</label>
                            <input class="form-control"
                                   name="name" type="text"
                                   placeholder="Enter Name" required>
                            <?php if($errors->has('name')): ?>
                                <div class="error"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>

                        </div>

                    </div>
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label for="">Price</label>
                            <input  type ="number"
                                    name="price"
                                    step="any"
                                    class="form-control"
                                    placeholder="Enter Amount" required>
                            <?php if($errors->has('price')): ?>
                                <div class="error"><?php echo e($errors->first('price')); ?></div>
                            <?php endif; ?>

                        </div>
                    </div>
                <div class="col-lg-3">
                    <div class="form-group">
                        <label for="">Credit</label>
                        <input  type ="number"
                                name="credit"
                                step="any"
                                class="form-control"
                                placeholder="Enter Credit" required>
                        <?php if($errors->has('credit')): ?>
                            <div class="error"><?php echo e($errors->first('credit')); ?></div>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="">Image</label>
                        <input type="file" class="form-control" name="image" accept="image/*">
                    </div>
                </div>



                <div class="col-md-12">
                    <div class="form-group">
                        <button class="btn btn-primary ml-2" type="submit">submit</button>
                    </div>
                </div>
            </form>

        </div>

    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/package/create.blade.php ENDPATH**/ ?>