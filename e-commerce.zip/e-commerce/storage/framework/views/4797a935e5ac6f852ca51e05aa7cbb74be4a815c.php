<div style="display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            padding: 50px;
            color: #0e0e0e;
">
    <div>
        <p><b>Hi,</b></p>
        <p> Your friend  <?php echo e($data['name']); ?>, sent you a request to join <b>billboardbd</b><br>
            If you want to join or see about <b>billboardbd</b> please visit following this url<br>
        <a href="http://www.billboardbd.com/?ref=20100<?php echo e($data['user_id']); ?>">
            http://www.billboardbd.com/?ref=20100<?php echo e($data['user_id']); ?> </a><br>

        <p>Thanks<br>
            BillBoardBD<br>
        </p>
    </div>
</div>
<?php /**PATH /var/www/html/e-commerce/resources/views/email/email-referral.blade.php ENDPATH**/ ?>