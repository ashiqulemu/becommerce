<?php if(session('message')): ?>
    <div class="flash-message">
        <?php if(session('type')=='success'): ?>
            <div class="alert alert-success" role="alert" id="successMessage">
                <?php else: ?>
                    <div class="alert alert-danger" role="alert" id="successMessage">
                        <?php endif; ?>
                        <div style="align-items: center">
                            <h4 class="alert-heading w-capitalize"><?php echo e(session('type')); ?> !</h4>
                            <p class="w-capitalize"><?php echo e(session('message')); ?></p>
                        </div>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
            </div>
    </div>
<?php endif; ?>

<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="<?php echo e(url('/admin/dashboard')); ?>">
            <img src="/images/logo-admin.png" alt="" class="brand-logo">
        </a>
    </div>
    <!-- /.navbar-header -->


    <ul class="nav navbar-top-links navbar-right">
        <!-- /.dropdown -->
        <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <div style="margin-top:10px;">
                    <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                </div>
            </a>
            <ul class="dropdown-menu dropdown-user">
                <li><a href="#"><i class="fa fa-user fa-fw"></i> Change Password</a>
                </li>


                <li class="divider"></li>
                <li>
                    <a class="d-block" href="<?php echo e(url('/admin/logout')); ?>"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fa fa-sign-out fa-fw"></i>Logout
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                              style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </a>
                </li>
            </ul>
            <!-- /.dropdown-user -->
        </li>
        <!-- /.dropdown -->
    </ul>
    <a class="site-link" href="<?php echo e(url('/')); ?>" style="color: #ff9a05">Visit Site</a>
    <!-- /.navbar-top-links -->
    <?php echo $__env->make('admin.includes.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</nav><?php /**PATH /var/www/html/e-commerce/resources/views/admin/includes/header.blade.php ENDPATH**/ ?>