

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <br>
        <div class="row site-forms">
            <form method="post" action="<?php echo e(url('/admin/category')); ?>">
               <?php echo csrf_field(); ?>
                <div class="">
                    <div class="form-box-header">
                        + Add Category
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="">Name</label>
                            <input v-model="name"
                                   class="form-control"
                                   name="name"
                                   type="text"
                                   placeholder="name">

                            <?php if($errors->has('name')): ?>
                                <div class="error"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="">Description</label>
                            <textarea class="form-control" name="description"></textarea>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="">Status</label><br>
                            <input type="radio" checked name="status" value="Active" id="active">
                            <label for="active">Active</label>
                            <input type="radio" name="status" value="Inactive"id="inactive">
                            <label for="inactive">Inactive</label>
                            <?php if($errors->has('status')): ?>
                                <div class="error"><?php echo e($errors->first('status')); ?></div>
                            <?php endif; ?>
                        </div>

                    </div>

                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <button class="btn btn-primary ml-2" type="submit">submit</button>
                    </div>
                </div>
            </form>

        </div>

    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/category/create.blade.php ENDPATH**/ ?>