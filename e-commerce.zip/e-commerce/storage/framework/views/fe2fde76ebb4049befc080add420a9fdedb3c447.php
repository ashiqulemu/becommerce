

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <br>
        <div class="row site-forms">
            <form method="post" action="<?php echo e(url('/admin/product/'.$product->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="">
                    <div class="form-box-header">
                        Edit Product
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label for="">Name *</label>
                            <input
                                    class="form-control"
                                    name="name"
                                    type="text"
                                    placeholder="name"
                                    value="<?php echo e(old('name', $product->name)); ?>"
                            >

                            <?php if($errors->has('name')): ?>
                                <div class="error"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">SKU Number *</label>
                            <input
                                    class="form-control"
                                    name="sku_number"
                                    type="text"
                                    placeholder="SKU Number"
                                    value="<?php echo e(old('sku_number',$product->sku_number)); ?>"
                            >

                            <?php if($errors->has('sku_number')): ?>
                                <div class="error"><?php echo e($errors->first('sku_number')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div>
                            <label for="">Category *</label>
                            <select class="js-example-basic-multiple form-control"
                                    name="category_id"  id="select1">
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categories->id); ?>"
                                    <?php if(old('category_id', $categories->id ) == $product->category_id): ?> <?php echo e('selected'); ?> <?php endif; ?>>
                                        <?php echo e($categories->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('category_id')): ?>
                                <div class="error"><?php echo e($errors->first('category_id')); ?></div>
                            <?php endif; ?>

                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Price *</label>
                            <input
                                    class="form-control"
                                    name="price"
                                    type="number"
                                    step="any"
                                    value="<?php echo e(old('price', $product->price)); ?>"
                                    placeholder="Price">

                            <?php if($errors->has('price')): ?>
                                <div class="error"><?php echo e($errors->first('price')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">Quantity *</label>
                            <input
                                    class="form-control"
                                    name="quantity"
                                    type="number"
                                    step="any"
                                    value="<?php echo e(old('quantity',$product->quantity)); ?>"
                                    placeholder="Quantity">

                            <?php if($errors->has('quantity')): ?>
                                <div class="error"><?php echo e($errors->first('quantity')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Description</label>
                            <textarea name="description" id="description"><?php echo e(old('description', $product->description)); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Meta Tag</label>
                            <input
                                    class="form-control"
                                    name="meta_tag"
                                    type="text"
                                    value="<?php echo e(old('meta_tag',$product->meta_tag)); ?>"
                                    placeholder="Meta Tag">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Meta Description</label>
                            <textarea name="meta_description" class="form-control"
                                      placeholder="Meta Description"><?php echo e(old('meta_description',$product->meta_description)); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Product Image</label>
                            <input type="file" class="form-control" name="images[]" accept="image/*" multiple><br>
                        </div>
                        <div>
                            <?php if(count($product->medias)): ?>
                            <div class="product-image-container">
                                <?php $__currentLoopData = $product->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="image-box">
                                        <img src="<?php echo e(asset("storage/$media->image")); ?>" alt="">
                                        <label class="check-product">
                                            <input type="checkbox" name="deleted_images[]" value="<?php echo e($media->id); ?>" checked/>
                                            <span><i class="fa fa-times"></i></span>
                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                           <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group"><br>
                            <label for="">Is Out of Stock? *</label><br>
                            <input type="radio"  name="is_out_of_stock" value="1" id="yes"
                                   <?php echo e(old('is_out_of_stock', $product->is_out_of_stock) =='1' ? 'checked' : ""); ?>>
                            <label for="yes">Yes</label>

                            <input type="radio"  name="is_out_of_stock" value="0" id="no"
                            <?php echo e(old('is_out_of_stock',$product->is_out_of_stock) =='0' ? 'checked' : ""); ?>>
                            <label for="no">No</label>
                            <?php if($errors->has('is_out_of_stock')): ?>
                                <div class="error"><?php echo e($errors->first('is_out_of_stock')); ?></div>
                            <?php endif; ?>
                        </div>

                    </div>
                    <div class="col-md-4">
                        <div class="form-group"><br>
                            <label for="">Status *</label><br>
                            <input type="radio" checked name="status" value="1" id="active"
                                 <?php echo e(old('status', $product->status) =="1" ? 'checked' : ""); ?>

                            >
                            <label for="active">Active</label>

                            <input type="radio" name="status" value="0" id="inactive"
                                    <?php echo e(old('status', $product->status) =="0" ? 'checked' : ""); ?>

                            >
                            <label for="inactive">Inactive</label>
                            <?php if($errors->has('status')): ?>
                                <div class="error"><?php echo e($errors->first('status')); ?></div>
                            <?php endif; ?>
                        </div>

                    </div>

                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <button class="btn btn-primary ml-2" type="submit">Update</button>
                    </div>
                </div>
            </form>

        </div>

    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/product/edit.blade.php ENDPATH**/ ?>