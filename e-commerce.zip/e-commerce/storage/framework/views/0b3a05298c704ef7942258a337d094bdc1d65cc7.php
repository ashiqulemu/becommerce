<section>
    <auction-slots></auction-slots>

</section><?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/auction-products.blade.php ENDPATH**/ ?>