

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <p class="pageTitle">
                    <i class="fa fa-cogs"></i>  manage auto bids
                </p>
            </div>
            <div class="col-md-12 ">
                <div class="overflow">
                    <table class="table table-striped  table-bordered table-hover" id="manageTable">
                        <thead>
                        <tr>
                            <th>SL </th>
                            <th>Auction Name</th>
                            <th>Bidder Name</th>
                            <th>Activate at price</th>
                            <th>Max Bix</th>
                            <th>Biding Type</th>
                            <th>Date & Time</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $autoBids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $autoBid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($autoBid->auction->name); ?></td>
                                <td><?php echo e($autoBid->user->name); ?></td>
                                <td><?php echo e($autoBid->activate_at_price); ?></td>
                                <td><?php echo e($autoBid->max_bid); ?></td>
                                <td>
                                    <?php echo e($autoBid->bid_randomly ? 'Bid Randomly' : ''); ?>

                                    <?php echo e($autoBid->bid_with_sec ? 'Bid With in last 10 sec' : ''); ?>

                                </td>
                                <td>
                                    <?php echo e($autoBid->created_at); ?>

                                </td>











                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>
                </div>




            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/bid/manage-auto-bid.blade.php ENDPATH**/ ?>