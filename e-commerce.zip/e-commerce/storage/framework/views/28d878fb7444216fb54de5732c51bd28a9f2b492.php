
<?php $__env->startSection('title-meta'); ?>
    <title>Confirm Payments</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()): ?>
        <?php echo $__env->make('site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('site.login.login-partitial.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <div class="container bg-white">
        <form method="post" action="<?php echo e(url('/make-payment')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row py-2 header">
                <div class="col-md-4"><br>
                    <h6 class="font-weight-bold">Delivery Information </h6>
                    <p></p>
                    <div class="deliverInfo">
                        <div class="form-group">
                            <label for="">Full Name <span class="text-danger">*</span></label>
                            <input type="text"
                                   class="form-control" id=""
                                   name="name"
                                   required
                                   value="<?php echo e(old('name', $user->name)); ?>"
                                   placeholder="Enter your full name ">
                            <?php if($errors->has('name')): ?>
                                <div class="error"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                            <input type="hidden" value="<?php echo e(request()->get('pcode')); ?>" name="package_code">
                        </div>

                        <div class="form-group">
                            <label for="">Mobile No <span class="text-danger">*</span></label>
                            <input type="number"
                                   name="mobile"
                                   class="form-control"
                                   required
                                   value="<?php echo e(old('mobile', $user->contact ? $user->contact->mobile: '')); ?>"
                                   placeholder="Mobile No">
                            <?php if($errors->has('mobile')): ?>
                                <div class="error"><?php echo e($errors->first('mobile')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <input type="text" class="form-control" name="address"
                                   value="<?php echo e(old('address', $user->contact ? $user->contact->address: '')); ?>"
                                   placeholder="For example : House 123, Street 123 "
                                   required
                            >
                            <?php if($errors->has('address')): ?>
                                <div class="error"><?php echo e($errors->first('address')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for=""> District <span class="text-danger">*</span></label>

                            <select class="form-control" name="district" required>
                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($district['name']); ?>"
                                    <?php if( old('district', $user->contact ? $user->contact->district : '' ) == $district['name'] ): ?>
                                        selected
                                    <?php endif; ?>
                                ><?php echo e($district['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('district')): ?>
                                <div class="error"><?php echo e($errors->first('district')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for=""> City <span class="text-danger">*</span> </label>
                            <input type="text"
                                   name="city"
                                   required
                                   value="<?php echo e(old('city', $user->contact ? $user->contact->city : '')); ?>"
                                   class="form-control"
                                   placeholder="City name">
                            <?php if($errors->has('city')): ?>
                                <div class="error"><?php echo e($errors->first('city')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for=""> Post Code</label>
                            <input type="number"
                                   name="post_code"
                                   value="<?php echo e(old('post_code', $user->contact ? $user->contact->post_code : '')); ?>"
                                   class="form-control"
                                   placeholder="Post Code">
                        </div>
                    </div>

                </div>
                <div class="col-md-4"><br>
                    <h6 class="font-weight-bold">Select a Payment Method</h6>
                    <p></p>
                    <ul class="payments">
                        <li>
                            <label class="payment-items">
                                <img src="/images/bkash.png" class="img-fluid">
                                <p>Bkash, Rocket, U-cash, Debit Card, Credit Card or Online Banking</p>
                                <input type="radio"
                                       name="payment_method"
                                       value="ssl" required
                                       <?php if(old('payment_method')=='ssl'): ?>
                                            checked
                                        <?php endif; ?>>
                            </label>
                        </li>
                        <li>
                            <label class="payment-items">
                                <img src="/images/dbbl.png" class="img-fluid">
                                <p>PayPal</p>
                                <input type="radio"
                                       name="payment_method"
                                       value="paypal"
                                       <?php if(old('payment_method')=='paypal'): ?>
                                             checked
                                        <?php endif; ?>>
                            </label>
                        </li>
                        <li>
                            <label class="payment-items">
                                <img src="/images/master-card.png" class="img-fluid">
                                <p>Cash On Deliver</p>
                                <input type="radio"
                                       name="payment_method"
                                       value="cash_on_delivery"
                                       <?php if(old('payment_method')=='cash_on_delivery'): ?>
                                        checked
                                        <?php endif; ?>>
                            </label>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <br>


                    <div class="basket">
                        <p class="title">Your Items</p>
                        <div class="confirmCart">
                            <div class="productList">
                                <?php
                                    $count=1;
                                    $subTotal=0;
                                ?>
                                <p class="font-weight-bold">
                                    <span>Product</span>
                                    <span>Quantity</span>
                                    <span>Total</span>
                                </p>
                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p>
                                        <span><?php echo e($count); ?>. <?php echo e($item->name); ?></span>
                                        <span><?php echo e($item->qty); ?></span>
                                        <span><?php echo e($setting->amount_sign); ?><?php echo e($item->price); ?></span>
                                    </p>
                                    <?php
                                        $count++;
                                         $subTotal+=$item->price*$item->qty;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="fix">
                                <p><span>Sub total </span><span><?php echo e($setting->amount_sign); ?><?php echo e($subTotal); ?></span></p>
                                <p><span>(+) Delivery cost </span>
                                    <span><?php echo e($setting->amount_sign); ?><?php echo e($shippingCost?$shippingCost->amount:0); ?></span>
                                </p>
                                <p>
                                <?php if($promotion): ?>

                                    <span>(-) Discount <?php echo e($promotion->sign=='Percentage'?
                                        '('.$promotion->amount.'%)':''); ?></span>
                                    <?php if($promotion->sign=='Percentage'): ?>
                                        <?php
                                            $discountAmount=($subTotal*
                                        $promotion->amount)/100
                                        ?>
                                        <span><?php echo e($setting->amount_sign); ?><?php echo e($discountAmount); ?></span>
                                    <?php else: ?>
                                        <?php
                                            $discountAmount=$promotion->amount
                                        ?>
                                        <span><?php echo e($setting->amount_sign); ?><?php echo e($promotion->amount); ?></span>
                                    <?php endif; ?>

                                <?php else: ?>
                                        <?php
                                            $discountAmount=0
                                        ?>
                                    <span>(-) Discount</span>
                                    <span><?php echo e($setting->amount_sign); ?>0</span>
                                <?php endif; ?>
                                </p>
                                <p class="mt-2 font-weight-bold">
                                    <span>Grand Total </span>
                                    <span><?php echo e($setting->amount_sign); ?>

                                        <?php echo e(($subTotal+($shippingCost?$shippingCost->amount:0)-$discountAmount)); ?></span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="buttonSection">

                            <a href="<?php echo e(url('/all-products')); ?>"
                               class="confirmPay shopping"
                               style="color: black;text-decoration: none"
                            >Continue Shopping!</a>

                        <button type="submit" class="confirmPay">Confirm Order!</button>
                    </div>

                </div>
            </div>
        </form>
    </div>




<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

    <style>


        .payments li {
            list-style: none;
            border-bottom: 3px double #ececec;
            border-top: 3px double #ececec;
            margin-bottom: 9px;
            transition: 0.4s all;
        }

        .payments li label {
            cursor: pointer;
            margin: 0;
        }

        .payments li:hover {
            border-bottom: 3px double #f4b234;
            border-top: 3px double #f4b234;
            background: #ececec;
        }

        .payments li .payment-items {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .payments li .payment-items:focus-within {
            background: #ffeeb3;
        }

        .payments li .payment-items img {
            flex: 1;
            max-width: 50px;
            border: 1px solid #ececec;
            padding: 8px;
            filter: saturate(0.4);
            transition: 0.4s all;
        }

        .payments li .payment-items p {
            flex: 3;
            margin-bottom: 0;
            padding: 6px 5px;
            line-height: 14px;
            font-size: 13px;
            color: #424242;
        }

        .payments li .payment-items input[type='radio'] {
            flex: 0.4;
            cursor: pointer;
        }

        .payments li .payment-items:hover img {
            filter: saturate(1);
        }
        .use-btn{
            line-height: 1.25;margin-top: -2px;
        }
    </style>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/pages/payment/confirmation.blade.php ENDPATH**/ ?>