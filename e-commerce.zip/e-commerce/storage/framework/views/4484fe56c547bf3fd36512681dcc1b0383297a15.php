

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <p class="pageTitle">
                    <i class="fa fa-cogs"></i> Auction Details
                </p>
            </div>
            <div class="col-md-12">
                <div class="product-actions">

                    <a  href="#" @click.prevent="deleteMe('<?php echo e('/admin/auction/'.$auction->id); ?>')" title="Delete">
                        <i class="fa fa-trash"></i>
                    </a>
                    <a href="<?php echo e(url('/admin/product/'.$auction->id).'/edit'); ?>" title="Edit">
                        <i class="fa fa-edit text-success"></i>
                    </a>
                </div>
                <div class="product-detail-view">
                    <div class="inner-description">
                        <div class="items">
                            <div class="heading">Auction name</div>
                            <div class="content"><b><?php echo e($auction->name); ?></b> </div>
                        </div>
                        <div class="items">
                            <div class="heading">Product name</div>
                            <div class="content">
                                <b><a href="<?php echo e(url('/admin/show-product/'.$auction->product->id)); ?>"><?php echo e($auction->product->name); ?></a></b>
                            </div>
                        </div>

                        <div class="items">
                            <div class="heading">Starting Price</div>
                            <div class="content"><b><?php echo e($auction->starting_price); ?></b> </div>
                        </div>
                        <div class="items">
                            <div class="heading">Cost per bid</div>
                            <div class="content"><b><?php echo e($auction->cost_per_bid); ?></b> </div>
                        </div>
                        <div class="items">
                            <div class="heading">Price Increase per bid</div>
                            <div class="content"><b><?php echo e($auction->price_increase_every_bid); ?></b> </div>
                        </div>
                        <div class="items">
                            <div class="heading">Price Drop Percentage</div>
                            <div class="content"><b><?php echo e($auction->price_drop_percentage); ?>%</b> </div>
                        </div>
                        <div class="items">
                            <div class="heading">Auction Type</div>
                            <div class="content"><b><?php echo e($auction->auction_type); ?></b> </div>
                        </div>
                        <div class="items">
                            <div class="heading">Up Time</div>
                            <div class="content"> <b><?php echo e($auction->up_time); ?></b> </div>
                        </div>
                        <div class="items">
                            <div class="heading">Auction Slots</div>
                            <div class="content">
                                <table class="table table-bordered table-hover table-striped">
                                    <thead>
                                    <tr>
                                        <th>Slot</th>
                                        <th>Slot Range</th>
                                        <th>Duration Time</th>
                                    </tr>

                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $auction->slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <?php if($key == 0): ?>
                                            <td> 0 - <?php echo e($slot->slot_number); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e($auction->slots[$key-1]->slot_number + 1); ?> - <?php echo e($slot->slot_number); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($slot->duration_time); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="items">
                            <div class="heading">Product Description</div>
                            <div class="content">  <?php echo $auction->description; ?></div>
                        </div>
                        <div class="items">
                            <div class="heading">Auction Images</div>
                            <div class="content">
                                <div class="gallery">
                                    <?php $__currentLoopData = $auction->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset("storage/$media->image")); ?>" alt="">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/auction/show.blade.php ENDPATH**/ ?>