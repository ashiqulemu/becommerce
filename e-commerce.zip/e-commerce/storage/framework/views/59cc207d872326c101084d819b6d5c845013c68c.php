
<?php $__env->startSection('title-meta'); ?>
    <title>Completed order </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('.site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('.site.login.login-partitial.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="myFirebidder">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>My Firebidders</h2>
                    <hr>
                </div>
                <div class="col-lg-3">
                    <?php $__env->startComponent('site.login.user.components.leftBar'); ?> <?php echo $__env->renderComponent(); ?>
                </div>
                <div class="col-lg-9 p-0">
                    <div class="userDetailsArea">
                        <h4 class="text-capitalize pb-3">Completed Order</h4>
                        <table class="table-striped table text-capitalize">
                            <thead>
                            <tr>
                                <th>Order No</th>
                                <th>Total Price</th>
                                <th>Order Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($orders)): ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <a href="<?php echo e('/order-invoice/'.$order->order_no); ?>">
                                                #<?php echo e($order->order_no); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <?php echo e($setting->amount_sign); ?>

                                            <?php echo e(($order->total + $order->shipping_cost) - $order->discount); ?>

                                        </td>
                                        <td> <?php echo e($order->order_status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3"> No order found.</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($orders->links()); ?>

                    </div>
                </div>
            </div>

        </div>
        </div>
    </section>
    <?php $__env->startComponent('site.login.user.components.user-sub-footer'); ?> <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/login/user/partial/completed-order.blade.php ENDPATH**/ ?>