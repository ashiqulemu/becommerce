<section>
    <div class="container products-area">
        <div class="row mx-auto">
            <?php $__currentLoopData = $closedAuctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $closedItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-lg-3 col-md-2 col-xs-2 ">
                    <div class="product wow fadeInUp" style="position: relative">
                        <div class="sold">
                            <div>closed</div>
                        </div>
                        <p class="name"><?php echo e($closedItem->name); ?></p>
                        <div class="photo">
                            <?php if(count($closedItem->medias)): ?>
                                <img src="<?php echo e(asset('storage/'.$closedItem->medias[0]->image)); ?>" class="photo" alt="">
                            <?php else: ?>
                                <img src="/images/products/1.png" class="photo" alt="">
                            <?php endif; ?>

                        </div>
                        <?php if(count($closedItem->bids) > 1): ?>
                            <div class="winner has-winner">
                                <img class="trophy" src="/images/trophy.png" alt="">
                                <?php echo e(substr(($closedItem->bids[count($closedItem->bids)-1]->user->username),0,18)); ?>


                            </div>

                            <div class="status">ended</div>
                            <div class="status-ended">winner</div>
                        <?php else: ?>
                            <div class="winner">
                                No Winner Selected
                            </div>
                            <div class="status">ended</div>
                        <?php endif; ?>

                        <div class="price font-weight-bold" style="margin-top: 35px">

                            <?php echo e($setting->amount_sign); ?>

                            <?php echo e(number_format((float)((count($closedItem->bids)*$closedItem->price_increase_every_bid)+$closedItem->starting_price), 2, '.', '')); ?></div>
                        
                        <?php if(count($closedItem->bids) > 1): ?>
                            <?php if(auth()->user()): ?>
                                <?php if($closedItem->bids[count($closedItem->bids)-1]->user->id == auth()->user()->id): ?>

                                    <?php if(!(\App\Auction::isSold($closedItem))): ?>
                                    <form method="post" action="<?php echo e(url('/add-to-cart')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div>
                                            <input type="hidden" name="qty" value="1">
                                            <input type="hidden" name="source" value="auction">
                                            <input type="hidden" name="source_id" value="<?php echo e($closedItem->id); ?>">
                                            <input type="hidden"
                                                   name="price"
                                                   value="<?php echo e((count($closedItem->bids) * $closedItem->price_increase_every_bid) + $closedItem->starting_price); ?>">
                                            <input type="hidden" name="id" value="<?php echo e($closedItem->product_id); ?>">
                                        </div>
                                        <button type="submit" class="closed">Buy Now</button>
                                    </form>
                                    <?php else: ?>
                                        <button class="closed">Sold</button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <button class="closed">Sold</button>
                                <?php endif; ?>
                            <?php else: ?>
                            <button class="closed">Sold</button>
                            <?php endif; ?>

                        <?php else: ?>
                            <button class="closed">Dismiss</button>
                        <?php endif; ?>

                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/closed-products.blade.php ENDPATH**/ ?>