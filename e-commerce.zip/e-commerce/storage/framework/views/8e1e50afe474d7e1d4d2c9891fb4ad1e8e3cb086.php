<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Admin </title>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('theme-assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('theme-assets/css/sb-admin-2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/table.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/summernote/summernote.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.datetimepicker.min.css')); ?>">



    <!-- Styles -->
</head>
<body>
    <div id="app" v-cloak >
        <div id="wrapper">
            <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form action="" method="post" id="deleteForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
            </form>
        </div>

    </div>

    <script src="<?php echo e(asset('js/admin.js')); ?>"></script>

    <script src="<?php echo e(asset('theme-assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme-assets/js/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme-assets/js/sb-admin-2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/table.js')); ?>"></script>
    <script src="<?php echo e(asset('js/theme-cust.js')); ?>"></script>
    <script src="<?php echo e(asset('js/editor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select.js')); ?>"></script>
    <script src="<?php echo e(asset('js/moment.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH /var/www/html/e-commerce/resources/views/admin/admin.blade.php ENDPATH**/ ?>