<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    
    <meta name="viewport" content="width=1024">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('title-meta'); ?>
    <meta http-equiv="refresh" content="900"/>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/smoothproducts.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('images/favi.png')); ?>">
    <!-- Styles -->
    <?php
        $date = new DateTime(); $serverTime = $date->format('Y-m-d H:i:s');
        $timeZone = $date->getTimezone()->getName();
    ?>

    <script>
        window.serverTime = "<?php echo e($serverTime); ?>";
        window.auth = "<?php echo e(request()->user()); ?>";
        window.currentPath = "<?php echo e(request()->path()); ?>";
        window.allAuctionSetTimout=[];
        window.timeZone="<?php echo e($timeZone); ?>";
    </script>
</head>
<body>

<div id="app" v-cloak>

    <?php if(session('message')): ?>
        <div class="flash-message">
            <?php if(session('type')=='success'): ?>
                <div class="alert alert-warning" role="alert" id="successMessage">
                    <?php else: ?>
                        <div class="alert alert-danger " role="alert" id="successMessage">
                            <?php endif; ?>

                            
                            <p class="w-capitalize"><?php echo e(session('message')); ?></p>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                </div>
        </div>
    <?php endif; ?>

    <?php echo $__env->make('site.home-partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('site.home-partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>








<script src="<?php echo e(mix('js/app.js')); ?>"></script>

<script src="<?php echo e(asset('js/smoothproducts.min.js')); ?>"></script>


<?php echo $__env->yieldContent('scripts'); ?>


<script src="<?php echo e(asset('js/zoom-image.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/custom.js')); ?>"></script>


</body>
</html>
<?php /**PATH /var/www/html/e-commerce/resources/views/site/app.blade.php ENDPATH**/ ?>