<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/login.css')); ?>">
</head>

<body>
<div class="login-section">
    <div class="login-box">
        <div class="brand">
           <img src="/images/logo-admin.png" width="200px" height="auto">
            
        </div>
        <form class="login-element" method="POST" action="<?php echo e(url('/admin/login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="item-rows">
                <label for="">Username :</label>
                <input id="login"
                       type="text"
                       class="form-item<?php echo e($errors->has('username') ||
                                               $errors->has('email') ? ' is-invalid' : ''); ?>"
                       placeholder="Username or email"
                       name="login" value="<?php echo e(old('username') ?: old('email')); ?>" required autofocus>
                <?php if($errors->has('username') || $errors->has('email')): ?>
                    <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('username') ?:
                                    $errors->first('email')); ?></strong>
                                            </span>
                <?php endif; ?>

            </div>
            <div class="item-rows">
                <label for="">Password:</label>
                <input id="password"
                       type="password"
                       class="form-item <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid
                                               <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                       name="password"
                       required
                       autocomplete="current-password"
                       placeholder="Password">

                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <div class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <input type="hidden" name="from" value="ad">
            </div>
            <div class="item-rows">
                <!-- <button class='login-btn'>Login</button> -->
                <button class='login-btn' type="submit">Login</button>
            </div>
        </form>



    </div>

</div>

</div>




</body>

</html><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/auth/login.blade.php ENDPATH**/ ?>