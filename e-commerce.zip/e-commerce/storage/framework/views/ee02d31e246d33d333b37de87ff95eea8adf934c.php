<section class="loged-header">
    <div class="container">
        <div class="header">
            <div>
                <div class="brand">
                    <a href="/user-home">
                        <img src="/images/logo.png" class="img-fluid d-block">
                    </a>
                </div>
            </div>
            <div>
                <ul>
                    
                    <li>
                        <i class="fa fa-user"></i>
                        <a href="<?php echo e(url('/user-details')); ?>"><?php echo e(auth()->user()->username); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/view-cart')); ?>" title="view shopping cart" class="shoppingCart">
                            <i class="fa fa-cart-plus text-warning" style="font-size: 34px">

                            </i>
                            <div class="counter"><?php echo e(Cart::content()->count()); ?></div>
                        </a>
                    </li>
                    <li>You have <?php echo e(auth()->user()->credit_balance); ?> credits</li>
                    <li>
                        <a href="<?php echo e(url('/credit-product')); ?>" class="btn btn-warning text-dark text-capitalize">top up credits</a>
                    </li>
                </ul>
            </div>
            <?php if(auth()->user()): ?>
                <div>
                    <a class="btn btn-outline-primary" href="<?php echo e(url('admin/logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        Logout
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                          style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section><?php /**PATH /var/www/html/e-commerce/resources/views//site/login/login-partitial/header.blade.php ENDPATH**/ ?>