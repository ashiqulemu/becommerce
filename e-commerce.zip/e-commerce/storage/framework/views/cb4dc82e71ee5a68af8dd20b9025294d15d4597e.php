
<?php $__env->startSection('title-meta'); ?>
    <title>Shopping Cart </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()): ?>
        <?php echo $__env->make('site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


    <div class="container bg-white aboutUS">
        <div class="row p-5 header">
            <div class="col-md-9 mx-auto">
                <br>
                <h3 class="shoppingTitle"
                    style="    background: rgb(249, 243, 220);
                    color: black">At a glance Your Shopping cart</h3><br>
                <div class="basket">
                    <p class="title">Your Basket</p>
                    <div class="confirmCart">
                        <div class="productList">
                            <?php
                                $count=1;
                                $subTotal=0;
                            ?>
                            <p class="font-weight-bold">
                                <span>Product</span>
                                <span style="flex: 1">Quantity</span>
                                <span style="width: 50px;">Total</span>
                                <span>Action</span>
                            </p>
                            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p>
                                    <span><?php echo e($count); ?>. <?php echo e($item->name); ?></span>
                                    <span style="flex: 1">
                                              <input type="number"
                                                     min="1"
                                                     class="text-center"
                                                     onchange="setCartUpdateUrl(<?php echo e($item->id.",'".$item->rowId."'"); ?>)"
                                                     onkeyup="setCartUpdateUrl(<?php echo e($item->id.",'".$item->rowId."'"); ?>)"
                                                     id="cartQuantity<?php echo e($item->id); ?>"
                                                     disabled
                                                     value="<?php echo e($item->qty); ?>"
                                                     style="width: 45px; padding:0 5px;">
                                    </span>
                                    <span style="width: 50px;"><?php echo e($setting->amount_sign); ?><?php echo e($item->price); ?></span>
                                    <span class="d-flex justify-content-end align-items-center">

                                     <?php if($item->options['source'] != 'auction'): ?>
                                     <i class="fa fa-edit" onclick="editCartItem(<?php echo e($item->id.",'".$item->rowId."'"); ?>)"
                                        id="cartEditBtn<?php echo e($item->id); ?>" title="Edit"></i>
                                    <?php endif; ?>
                                    <a href="<?php echo e(url('/delete/cart-item/'.$item->rowId)); ?>"
                                       title="Delete">
                                        <i class="fa fa-trash text-danger mx-2"></i>
                                    </a>

                                            <a href="#" id="cartUpdateUrl<?php echo e($item->id); ?>" class="text-success" title="Update">
                                                                    <i class="fa fa-check"
                                                                       id="cartUpdateBtn<?php echo e($item->id); ?>"
                                                                       style="display: none;"></i>

                                             </a>



                                </span>
                                </p>
                                <?php
                                    $count++;
                                     $subTotal+=$item->price*$item->qty;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <div class="fix px-2 fixCart">
                            <p class="mb-3">
                                <small class="font-weight-bold">Promo Code</small>
                                <span>
                                        <input type="text"
                                               class="promo"
                                               id="promoInput"
                                               onchange="setPromoLink()"
                                               onkeyup="setPromoLink()"
                                               style=" height: 30px;  vertical-align: middle;"
                                        >
                                        <a href="#"
                                           id="promoLink"
                                           class="btn btn-sm btn-warning use-btn"
                                        >use</a>
                               </span>
                            </p>
                            <p><span>Sub total </span><span><?php echo e($setting->amount_sign); ?><?php echo e($subTotal); ?></span></p>
                            <p><span>(+) Delivery cost </span>
                                <span><?php echo e($setting->amount_sign); ?><?php echo e($shippingCost?$shippingCost->amount:0); ?></span>
                            </p>
                            <p>
                                <?php if($promotion): ?>

                                    <span>(-) Discount <?php echo e($promotion->sign=='Percentage'?
                                        '('.$promotion->amount.'%)':''); ?></span>
                                    <?php if($promotion->sign=='Percentage'): ?>
                                        <?php
                                            $discountAmount=($subTotal*
                                        $promotion->amount)/100
                                        ?>
                                        <span><?php echo e($setting->amount_sign); ?><?php echo e($discountAmount); ?></span>
                                    <?php else: ?>
                                        <?php
                                            $discountAmount=$promotion->amount
                                        ?>
                                        <span><?php echo e($setting->amount_sign); ?><?php echo e($promotion->amount); ?></span>
                                    <?php endif; ?>

                                <?php else: ?>
                                    <?php
                                        $discountAmount=0
                                    ?>
                                    <span>(-) Discount</span>
                                    <span><?php echo e($setting->amount_sign); ?>0</span>
                                <?php endif; ?>
                            </p>
                            <p class="mt-2 font-weight-bold">
                                <span>Grand Total </span>
                                <span><?php echo e($setting->amount_sign); ?>

                                    <?php echo e(($subTotal+($shippingCost?$shippingCost->amount:0)-$discountAmount)); ?></span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="buttonSection" style="width: 50%;float: right;">
                    <a href="<?php echo e(url('/all-products')); ?>"
                       class="confirmPay shopping"
                       style="color: black;
                                background: #dadada;
                           text-decoration: none;"
                    >Continue Shopping!</a>

                    <?php if(request()->input('pcode')): ?>
                        <a href="<?php echo e(url('/payment-confirmation?pcode='.request()->
                                input('pcode'))); ?>"
                           class="confirmPay"
                           style="background: #6174ff;color:black;
                                   text-decoration: none">Go to checkout</a>
                    <?php else: ?>
                        <a href="<?php echo e(url('/payment-confirmation')); ?>"
                           class="confirmPay"
                           style="background: #6174ff;
                           color:black;
                           text-decoration: none"
                        >
                            Go to checkout</a>
                    <?php endif; ?>

                </div>

            </div>
        </div>


    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        function setPromoLink() {
            var val = $('#promoInput').val()
            $('#promoLink').attr('href', '/view-cart?pcode=' + val)
        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/pages/cart/cart.blade.php ENDPATH**/ ?>