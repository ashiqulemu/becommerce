
<?php $__env->startSection('title-meta'); ?>
    <title>Order Invoice</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="container bg-white mt-5">

        <i class="fa fa-print printInvoiceBtn" onclick="printMe()"></i>


        <div id="orderInvoice" class="invoiceArea">
            <div class="rows">
                <div class="column">
                    <img width='190px' src="/images/logo.png" alt="">

                </div>
                <div class="column">
                    <strong>
                        Order Number  #<?php echo e($order->order_no); ?> <br>
                        Order Date & Time <br>
                        <?php echo e($order->created_at); ?>

                    </strong>
                </div>
            </div>
            <hr>
            <div class="rows">
                <div class="column">
                    Invoice to:<br>
                    <strong>
                        <?php echo e($order->user_name); ?><br>
                        Phone: <?php echo e($order->mobile); ?><br>
                    </strong>
                    <br>
                    <br>
                </div>
                <div class="column">
                    Delivery Address<br>
                    <strong>
                        <?php echo e($order->address); ?><br>
                        <?php echo e($order->city); ?><br>
                        <?php echo e($order->district); ?> <?php echo e($order->post_code); ?> <br>
                    </strong>
                </div>
            </div>


            <table class="table invoiceTable">
                <thead>
                <tr>
                    <th scope="col">Sl</th>
                    <th scope="col">Product</th>
                    <th scope="col">Qty</th>
                    <th scope="col">Price</th>
                    <th scope="col">Total Per Item</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <?php
                        $subTotal = 0;
                    ?>
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->product->name); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td><?php echo e($setting->amount_sign); ?><?php echo e($item->unit_price); ?></td>
                            <td><?php echo e($setting->amount_sign); ?><?php echo e(number_format((float)($item->quantity * $item->unit_price), 2, '.', '')); ?></td>
                            <?php
                                $subTotal += ($item->quantity * $item->unit_price)
                            ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <div class="rows-invoice">
                <div class="items">&nbsp; </div>
                <div class="items">

                       <div class="item-row">
                           <span>Sub total :</span>
                           <span><?php echo e($setting->amount_sign); ?><?php echo e(number_format((float)($subTotal), 2, '.', '')); ?></span>
                       </div>
                       <div class="item-row">
                           <span>(-) Discount :</span>
                           <span><?php echo e($setting->amount_sign); ?><?php echo e(number_format((float)($order->discount), 2, '.', '')); ?></span>
                       </div>
                       <div class="item-row">
                           <span> (+) Shipping Cost :</span>
                           <span> <?php echo e($setting->amount_sign); ?><?php echo e(number_format((float)($order->shipping_cost), 2, '.', '')); ?></span>
                       </div>
                       <div class="item-row">
                           <span> Grand total :</span>
                           <span> <?php echo e($setting->amount_sign); ?><?php echo e(number_format((float)(($subTotal - $order->discount) + $order->shipping_cost ), 2, '.', '')); ?></span>
                       </div>



                </div>
            </div>


            <strong>
                <h6 align='center'> www.billboardbd.com Dhaka Bangladesh Phone: 77665544222, Email:
                    order@billboardbd.com
                </h6>
            </strong>

        </div>

        <br>
        <br>
    </div>




<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>

        function printMe() {
            window.print();
        }

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/pages/payment/order-invoice.blade.php ENDPATH**/ ?>