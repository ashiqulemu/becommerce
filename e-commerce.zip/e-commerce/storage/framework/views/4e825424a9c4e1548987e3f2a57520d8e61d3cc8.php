<section>
    <div class="container offers-area">
        <div class="row p-1">
            <div class="offers">
                YOU CAN SAVE UP TO 90% WITH OUR OFFERS!
            </div>
        </div>
    </div>
</section><?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/offers.blade.php ENDPATH**/ ?>