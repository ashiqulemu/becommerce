
<?php $__env->startSection('title-meta'); ?>
    <title>Statistic </title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('.site.login.login-partitial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('.site.login.login-partitial.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="myFirebidder">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>My Firebidders</h2>
                    <hr>
                </div>
                <div class="col-lg-3">
                    <?php $__env->startComponent('site.login.user.components.leftBar'); ?> <?php echo $__env->renderComponent(); ?>
                </div>
                <div class="col-lg-9 p-0">
                    <div class="userDetailsArea">
                        <h4 class="text-capitalize pb-3">My Statistics</h4>
                        <table class="table-striped table text-capitalize">
                            <tr>
                                <td> Auction Participated</td>
                                <td> <?php echo e($participate); ?></td>
                            </tr>
                            <tr>
                                <td> Auction Won</td>
                                <td>
                                    <?php
                                        $won = 0;
                                    ?>
                                    <?php $__currentLoopData = $wonAuctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(count($item->bids) > 1): ?>
                                            <?php if($item->bids[count($item->bids)-1]->user->id == auth()->user()->id): ?>
                                                <?php
                                                    $won++;
                                                ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($won); ?>

                                </td>
                            </tr>
                            <tr>
                                <td> Credits Used</td>
                                <td> <?php echo e($creditUsed); ?></td>
                            </tr>
                            <tr>
                                <td> Credits Bought</td>
                                <td> <?php echo e($creditBought); ?></td>
                            </tr>
                            <tr>
                                <td> Welcome credit </td>
                                <td> <?php echo e($user->singUp_credit); ?></td>
                            </tr>
                            <tr>
                                <td> Referral credit </td>
                                <td> <?php echo e($user->referral_credit); ?></td>
                            </tr>
                            <tr>
                                <td> Credits Left</td>
                                <td> <?php echo e($creditLeft + ($user->singUp_credit + $user->referral_credit)); ?></td>
                            </tr>
                        </table>

                    </div>
                </div>
            </div>

        </div>
        </div>
    </section>
    <?php $__env->startComponent('site.login.user.components.user-sub-footer'); ?> <?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/site/login/user/partial/statistic.blade.php ENDPATH**/ ?>