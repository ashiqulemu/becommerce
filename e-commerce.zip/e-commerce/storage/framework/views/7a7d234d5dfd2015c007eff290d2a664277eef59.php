<div class="panel-group" id="accordion">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse"   data-parent="#accordion" href="#collapse0" aria-expanded="true">My
                    Information</a>
            </h4>
        </div>
        <div id="collapse0" class="panel-collapse collapse in">
            <div class="panel-body">
                <div class="inner">
                    <a id='my_information' href="<?php echo e(url('/user-details')); ?>" >Personal Information</a>
                    <a id='edit_setting' href="<?php echo e(url('/user-details/settings')); ?>">Edit Information</a>
                    <a id='changePassword' href="<?php echo e(url('/user-details/change-password')); ?>">Change Password</a>
                </div>
            </div>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">My Auctions</a>
            </h4>
        </div>
        <div id="collapse1" class="panel-collapse collapse in">
            <div class="panel-body">
                <div class="inner">
                    <a id="statistic" href="<?php echo e(url('/user-details/statistic')); ?>">Statistics</a>
                    <a id="biddingHistory" href="<?php echo e(url('/user-details/bidding-history')); ?>">Bidding History</a>
                    <a id="creditBuyingHistory" href="<?php echo e(url('/user-details/credit-buy-history')); ?>">Credit buying history</a>
                </div>
            </div>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">My Referral</a>
            </h4>
        </div>
        <div id="collapse2" class="panel-collapse collapse in">
            <div class="panel-body">
                <div class="inner">
                    <a id="addReferral" href="<?php echo e(url('/user-details/referral')); ?>">Referral info</a>
                    <a id="referFriend" href="<?php echo e(url('/user-details/referral-friend')); ?>">Refer friend</a>
                </div>
            </div>
        </div>
    </div>































    <div class="panel panel-default">
        <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">My
                    Orders</a>
            </h4>
        </div>
        <div id="collapse5" class="panel-collapse collapse">
            <div class="panel-body">
                <div class="inner">
                    <a id="allOrder" href="<?php echo e(url('/user-details/all-order')); ?>">All Order</a>
                    <a id="shipmentOrder" href="<?php echo e(url('/user-details/shipment-order')); ?>">Shipment Order</a>
                    <a id="completedOrder" href="<?php echo e(url('/user-details/completed-order')); ?>">Completed Orders</a>
                    <a id="cancelOrder" href="<?php echo e(url('/user-details/cancel-order')); ?>">Cancel Order</a>
                </div>
            </div>
        </div>
    </div>

</div>

<?php /**PATH /var/www/html/e-commerce/resources/views/site/login/user/components/leftBar.blade.php ENDPATH**/ ?>