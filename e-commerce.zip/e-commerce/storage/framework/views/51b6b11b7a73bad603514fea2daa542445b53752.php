<section>
    <div class="container featured-product">
        <div class="row ">
            <div class="col-md-12 p-0">
                <p class="section-title">FEATURES PRODUCTS</p>
            </div>
            <div class="col-lg-5 pl-0">
                <div class="product-bid-rules">
                    <ul class="attribute">
                        <li>bid on warehouse products</li>
                        <li>bid on warehouse closeouts</li>
                        <li>bid on overstock supluses</li>
                        <li>bid on wholesale stock</li>
                        <li>bid on manufacturer stock</li>
                        <li>and more </li>

                    </ul>
                </div>
            </div>
            <div class="col-lg-7 pr-0">
                <div>
                    <img src="/images/home/featured.png" class="img-fluid d-block" alt="">
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/features-products.blade.php ENDPATH**/ ?>