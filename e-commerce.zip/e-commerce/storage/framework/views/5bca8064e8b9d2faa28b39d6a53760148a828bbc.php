<section class="bottomBar">
    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <div class="footerFixedLinks ">
                    <i class="fa fa-cog"></i>
                    <a href="<?php echo e(url('user-details/bidding-history')); ?>">
                        My FireBid
                    </a>
                    <i class="fa fa-star"></i>
                    <a href="<?php echo e(url('user-details/credit-buy-history')); ?>">
                        Credits(<?php echo e(auth()->user()->credit_balance); ?>)
                    </a>
                    <i class="fa fa-font"></i>
                    <a href="<?php echo e(url('/auto-bid/create')); ?>">
                        Auto-bid
                    </a>




                </div>
            </div>






        </div>
    </div>
</section><?php /**PATH /var/www/html/e-commerce/resources/views/site/login/user/components/user-sub-footer.blade.php ENDPATH**/ ?>