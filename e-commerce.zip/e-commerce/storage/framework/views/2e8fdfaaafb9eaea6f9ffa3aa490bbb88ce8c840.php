<section>
    <div class="container products-area regular-product" id="regularProduct">
        <div class="row mx-auto">
            <div class="col-lg-12 p-1">
                <a href="<?php echo e(url('/all-products')); ?>" class="title" style="position: relative">
                    Regular Products
                    
                    <span class="hints">View All Products</span>
                </a>
            </div>
            <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-2 p-1">
                <div class="product wow fadeInUp default-a">
                    <a href="<?php echo e(url('product/details/'.$product->id).'/'.$product->name); ?>">
                    <p class="name"><?php echo e($product->name); ?></p>
                      <div class="photo">
                            <?php $__currentLoopData = $product->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($key==0): ?>
                                  <img src="<?php echo e(asset("storage/$media->image")); ?>" alt=""
                                       class="photo">
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                    </a>
                    <div class="price font-weight-bold"><?php echo e($setting->amount_sign); ?><?php echo e($product->price); ?></div>
                    <div class="byNowBasket">
                        <a class="btn closed " href="<?php echo e(url('product/details/'.$product->id).'/'.$product->name); ?>">Details</a>
                            <form method="post" action="<?php echo e(url('/add-to-cart')); ?>">
                                <?php echo csrf_field(); ?>

                                <input type="hidden" name="qty" min="1" value="1">
                                <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                <button type="submit" class="btn  closed d-flex justify-content-center align-items-center">
                                    <span>+</span>
                                    <span>&nbsp;Basket</span>
                                </button>
                            </form>
                        
                    </div>
                </div>

            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</section>
<?php /**PATH /var/www/html/e-commerce/resources/views/site/home-partials/regular-product.blade.php ENDPATH**/ ?>