<div style="display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            padding: 50px;
            color: #0e0e0e;
">
    <div>
        <p><b>Hi <?php echo e($data['name']); ?>,</b></p>
        <p> Welcome to our BillboardBD, really thanks to join with us. We add some credit to your account<br>
            you can use it and if you want to more refer some friend to <b>BillboardBD</b> <br>
            if you need any help feel free contact with us.
        </p>
        <p>Thanks<br>
            BillBoardBD<br>
        </p>
    </div>
</div>
<?php /**PATH /var/www/html/e-commerce/resources/views/email/email-welcome.blade.php ENDPATH**/ ?>