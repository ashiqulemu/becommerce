

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <p class="pageTitle">
                    <i class="fa fa-cogs"></i>  manage sales
                </p>
            </div>
            <div class="col-md-12 ">

                <div class="overflow">
                    <table class="table table-striped  table-bordered table-hover" id="manageTable">
                        <thead>
                        <tr>
                            <th>SL </th>
                            <th>Order No</th>
                            <th>Total Price</th>
                            <th>Payment Type</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/order-invoice/'. $sale->order_no)); ?>" target="_blank">
                                        #<?php echo e($sale->order_no); ?>

                                    </a>
                                </td>
                                <td><?php echo e($sale->total); ?></td>
                                <td><?php echo e($sale->payment_type); ?></td>
                                <td>
                                    <select  class="form-control"
                                             name="section"
                                             id="orderStatus<?php echo e($sale->id); ?>"
                                             required
                                             placeholder="Select Section">
                                                <?php $__currentLoopData = ['On Process', 'Shipped', 'Delivered', 'Cancel']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item); ?>"
                                                            <?php if($item == $sale->order_status): ?> selected <?php endif; ?>
                                                    > <?php echo e($item); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td>
                                    <div>
                                        <a href="#" onclick="changeOrderStatus(<?php echo e($sale->id); ?>)" title="Update">
                                            <i class="fa fa-check"></i>
                                        </a>



                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('.modal-btn').click(function () {
            const order = JSON.parse($(this).attr('data-order'));
            $('#orderDettails').text("#" + order.order_no +" order details")
            console.log(order)
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-commerce/resources/views/admin/pages/sales/manage.blade.php ENDPATH**/ ?>